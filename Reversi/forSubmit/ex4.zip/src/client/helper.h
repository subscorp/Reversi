/******************************************
*Ori Hirshfeld
*201085776
*Amichai Wollin
*300582392
******************************************/

#pragma once

typedef struct possibleMove
{
	int x;
	int y;
}location;

